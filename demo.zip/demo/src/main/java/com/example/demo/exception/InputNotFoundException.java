package com.example.demo.exception;

public class InputNotFoundException extends RuntimeException{
	public InputNotFoundException() {
		super();
	}
}
