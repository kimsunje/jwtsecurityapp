package com.example;

public class InputNotFoundException extends RuntimeException{
	public InputNotFoundException() {
		super();
	}
}
