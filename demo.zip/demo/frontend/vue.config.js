module.exports = {
  outputDir: "../src/main/resources/static",
  indexPath: "index.html",
  "transpileDependencies": [
    "vuetify"
  ]
}